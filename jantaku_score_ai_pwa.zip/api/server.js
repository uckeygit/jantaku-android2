// Node.js 18+ / OpenAI vision proxy. Keep API key on the server, never in browser code.
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json({limit:"12mb"}));
app.use(express.static(path.join(__dirname,"..")));
app.post("/api/recognize",async(req,res)=>{
 try{
  const key=process.env.OPENAI_API_KEY;
  if(!key)return res.status(503).json({error:"サーバーにOPENAI_API_KEYが設定されていません。"});
  const image=req.body?.image;
  if(typeof image!=="string"||!/^data:image\/(jpeg|jpg|png|webp);base64,/.test(image))return res.status(400).json({error:"JPEG/PNG/WEBP画像を選択してください。"});
  const prompt=`あなたは日本のリーチ麻雀の牌姿読み取り補助AIです。画像から確実に見える牌だけを読み取ってください。見えない牌や不明点を作り上げないでください。ドラ表示牌、赤ドラ、手牌、鳴き、副露、あがり牌が区別できる場合に記述。役と翻・符は画像だけでは確定できない場合が多いので、確信がなければhan/fuをnullにし、notesに不足情報を具体的に書く。リーチ/一発/海底/河底/嶺上/槍槓/ダブル役満等、写真から見えない状況役を勝手に付けない。出力は指定JSONのみ。`;
  const response=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({model:process.env.OPENAI_VISION_MODEL||"gpt-4.1-mini",input:[{role:"user",content:[{type:"input_text",text:prompt},{type:"input_image",image_url:image,detail:"high"}]}],text:{format:{type:"json_schema",name:"mahjong_image_reading",strict:true,schema:{type:"object",additionalProperties:false,properties:{tiles:{type:"array",items:{type:"string"}},yaku:{type:"array",items:{type:"object",additionalProperties:false,properties:{name:{type:"string"},han:{type:["integer","null"]}},required:["name","han"]}},han:{type:["integer","null"]},fu:{type:["integer","null"]},winType:{type:["string","null"],enum:["ron","tsumo",null]},dealer:{type:["boolean","null"]},notes:{type:"string"}},required:["tiles","yaku","han","fu","winType","dealer","notes"]}}}})});
  const payload=await response.json();
  if(!response.ok)return res.status(response.status).json({error:payload.error?.message||"AIサービスからエラーが返りました。"});
  const output=(payload.output||[]).flatMap(x=>x.content||[]).find(x=>x.type==="output_text")?.text;
  if(!output)return res.status(502).json({error:"AIの解析結果を取得できませんでした。"});
  res.json(JSON.parse(output));
 }catch(e){res.status(500).json({error:"解析処理でエラーが発生しました。サーバーログを確認してください。"});}
});
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`Mahjong score app listening on ${port}`));
